-- Using the view to select data
SELECT * FROM emp_dept_view;

-- Using the high earners view
SELECT * FROM high_earners_view;

-- Aggregate using a view
SELECT department_name, AVG(salary) AS avg_salary
FROM emp_dept_view
GROUP BY department_name;
