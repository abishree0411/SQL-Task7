-- Insert sample data
INSERT INTO employees VALUES (1, 'Alice', 1, 60000);
INSERT INTO employees VALUES (2, 'Bob', 2, 55000);
INSERT INTO employees VALUES (3, 'Charlie', 1, 70000);
INSERT INTO employees VALUES (4, 'David', 3, 45000);

INSERT INTO departments VALUES (1, 'HR');
INSERT INTO departments VALUES (2, 'IT');
INSERT INTO departments VALUES (3, 'Finance');
