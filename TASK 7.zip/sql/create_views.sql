-- Create a view showing employee info with department name
CREATE VIEW emp_dept_view AS
SELECT e.emp_id, e.name, d.department_name, e.salary
FROM employees e
JOIN departments d ON e.department_id = d.department_id;

-- Create a view for high earners
CREATE VIEW high_earners_view AS
SELECT name, salary
FROM employees
WHERE salary > 60000;
