-- Create example tables
CREATE TABLE employees (
    emp_id INTEGER PRIMARY KEY,
    name TEXT,
    department_id INTEGER,
    salary REAL
);

CREATE TABLE departments (
    department_id INTEGER PRIMARY KEY,
    department_name TEXT
);
